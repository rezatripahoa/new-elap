<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\CenterController;
use App\Http\Controllers\CommissionController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\FrontHeadController;
use App\Http\Controllers\FrontPusatController;
use App\Http\Controllers\FrontUserController;
use App\Http\Controllers\HeadController;
use App\Http\Controllers\ProgramKerjaController;
use App\Http\Controllers\ProgramKerjaTypeController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\YearController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [AuthController::class, 'index']);
Route::get('login', [AuthController::class, 'index']);
Route::post('login_submit', [AuthController::class, 'login_submit']);
Route::get('logout', [AuthController::class, 'logout']);

Route::get('change_password', [AuthController::class, 'changePassword']);
Route::post('change_password_submit', [AuthController::class, 'changePasswordSubmit']);

Route::group(['middleware' => 'role:1'], function () {
    Route::prefix('admin')->group(function () {
        Route::get('dashboard', [DashboardController::class, 'index']);
        Route::resource('category', CategoryController::class);
        Route::resource('year', YearController::class);
        Route::resource('center', CenterController::class);
        Route::resource('department', DepartmentController::class);
        Route::resource('head', HeadController::class);
        Route::resource('commission', CommissionController::class);
        Route::resource('type', ProgramKerjaTypeController::class);
        Route::get('department_report', [ReportController::class, 'index']);
        Route::get('report/{id}', [ReportController::class, 'report']);
    });
});

Route::group(['middleware' => 'role:2'], function () {
    Route::prefix('report')->group(function () {
        Route::get('dashboard', [FrontPusatController::class, 'index']);
        Route::get('list_report/{id}', [FrontPusatController::class, 'report']);
    });
});

Route::group(['middleware' => 'role:3'], function () {
    Route::prefix('department')->group(function () {
        Route::get('dashboard', [FrontUserController::class, 'index']);

        Route::post('laporan_kegiatan', [FrontUserController::class, 'laporan_kegiatan_submit']);
        Route::post('laporan_keuangan', [FrontUserController::class, 'laporan_keuangan_submit']);

        Route::resource('program_kerja', ProgramKerjaController::class);
    });
});

Route::group(['middleware' => 'role:4'], function () {
    Route::prefix('head')->group(function () {
        Route::get('dashboard', [FrontHeadController::class, 'index']);
    });
});
