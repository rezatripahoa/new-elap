<?php $__env->startSection('content'); ?>
    <?php
        $url_narasi = 'laporan_narasi_admin';
        $url_pka = 'program_kerja_admin';
        $url_kegiatan = 'laporan_kegiatan_admin';
        $url_gabungan = 'laporan_gabungan_admin';
        if (auth()->user()->role == 1) {
            $url_narasi = 'admin/' . $url_narasi . '_admin';
            $url_gabungan = 'admin/' . $url_gabungan . '_admin';
            $url_pka = 'admin/' . $url_pka . '_admin';
            $url_kegiatan = 'admin/' . $url_kegiatan . '_admin';
        } elseif (auth()->user()->role == 2) {
            $url_narasi = 'report/' . $url_narasi . '_report';
            $url_gabungan = 'report/' . $url_gabungan . '_report';
            $url_pka = 'report/' . $url_pka . '_report';
            $url_kegiatan = 'report/' . $url_kegiatan . '_report';
        }
        $year = date('Y') . ' - ' . date('Y') + 1;
    ?>
    <main>
        <p class="text-center text-secondary font-weight-bold h2 p-3">
            List Department
        </p>

        <div class="container my-2" style="min-height: 50vh">
            <div class="row mt-3">
                <div class="col-md-12">
                    <table id="tableData" class="table table-striped" style="width:100%">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Nama Department</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $no=1; ?>
                            <?php $__currentLoopData = $data['list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no); ?>.</td>
                                    <td><?php echo e($department->department_name); ?></td>
                                    <td align="center">
                                        
                                        <a class="btn btn-sm btn-realblue mb-1" style="width: 200px"
                                            href="<?php echo e(url($url_pka . '/' . $department->id)); ?>?year=<?php echo e($year); ?>">PKA</a>
                                        <a class="btn btn-sm btn-realblue mb-1" style="width: 200px"
                                            href="<?php echo e(url($url_kegiatan . '/' . $department->id)); ?>">Lihat
                                            Laporan Kegiatan</a>
                                        <a class="btn btn-sm btn-realblue mb-1" style="width: 200px"
                                            href="<?php echo e(url($url_narasi . '/' . $department->id)); ?>">Lihat
                                            Laporan Narasi</a>
                                        <a class="btn btn-sm btn-realblue" style="width: 200px"
                                            href="<?php echo e(url($url_gabungan . '/' . $department->id)); ?>">Lihat
                                            Laporan Gabungan</a>
                                    </td>
                                </tr>
                                <?php $no++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\e-lap.mygpib.com\e-lap.mygpib.com\resources\views/admin/report/list_department.blade.php ENDPATH**/ ?>