<div class="bg-white rounded d-none d-md-block">
    <div class="p-3 h5 font-weight-bold">
        <div class="">
            <i class="fa fa-book" style="font-size:20px;"></i>
            <?php $year = date('Y') . ' - ' . date('Y') + 1; ?>
            <a class="text-dark ml-3" href="<?php echo e(url('department/dashboard?year=' . $year)); ?>">Laporan</a>
        </div>
    </div>
</div>
<?php /**PATH /home/n1605061/public_html/e-lap.mygpib.com/resources/views/user/section/sidebar.blade.php ENDPATH**/ ?>