

<?php $__env->startSection('content'); ?>
    <?php
        $url_base = 'laporan_narasi_admin';
        $url_narasi = 'laporan_narasi_generate_admin';
        $url_program = 'laporan_program_generate_admin';
        if (auth()->user()->role == 1) {
            $url_base = 'admin/' . $url_base . '_admin';
            $url_narasi = 'admin/' . $url_narasi . '_admin';
            $url_program = 'admin/' . $url_program . '_admin';
        } elseif (auth()->user()->role == 2) {
            $url_base = 'report/' . $url_base . '_report';
            $url_narasi = 'report/' . $url_narasi . '_report';
            $url_program = 'report/' . $url_program . '_report';
        }
    ?>
    <main>
        <p class="text-center text-secondary font-weight-bold h2 p-3">
            Laporan Program Kerja <?php echo e($data['department']->department_name); ?>

        </p>

        <div class="row px-4">
            <form class="form-inline" action="<?php echo e(url($url_base . '/' . $data['department']->id)); ?>" method="GET">
                <div class="form-group mr-2">
                    <select name="year" class="form-control">
                        <option>Pilih Tahun</option>
                        <?php $__currentLoopData = $data['year']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php if($item->id == $data['curr_year']): ?> selected <?php endif; ?>>
                                <?php echo e($item->year_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group mr-2">
                    <select name="category" class="form-control">
                        <option>Pilih Fase Program</option>
                        <?php $__currentLoopData = $data['category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php if($item->id == $data['curr_category']): ?> selected <?php endif; ?>>
                                <?php echo e($item->category_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <button class="btn btn-realblue" type="submit">Apply</button>
                </div>
            </form>
        </div>

        <div class="container my-2" style="min-height: 50vh">
            <div class="row mt-3">
                <div class="col-md-12">
                    <table id="tableData" class="table table-striped" style="width:100%">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Nama Program</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $no=1; ?>
                            <?php $__currentLoopData = $data['list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no); ?>.</td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td>
                                        <a class="btn btn-realblue w-100 mb-2" target="_blank"
                                            href="<?php echo e(url($url_narasi . '/' . $item->id . '/' . $data['department']->id . '?category=' . $data['curr_category'])); ?>">Print
                                            Laporan Narasi</a>
                                        <a class="btn btn-realblue w-100 mb-2" target="_blank"
                                            href="<?php echo e(url($url_program . '/' . $item->id . '/' . $data['department']->id . '?category=' . $data['curr_category'])); ?>">Print
                                            Laporan Program</a>
                                    </td>
                                </tr>
                                <?php $no++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if(count($data['list']) == 0): ?>
                                <tr>
                                    <td colspan="3" align="center">Tidak Ada Data (Pilih Tahun dan Kategori Lain)</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\e-lap.mygpib.com\e-lap.mygpib.com\resources\views/admin/laporan_narasi/index.blade.php ENDPATH**/ ?>