<div class="bg-white rounded d-none d-md-block">
    <div class="p-3 h5 font-weight-bold">
        <div class="">
            <i class="fa fa-book" style="font-size:20px;"></i>
            <a class="text-dark ml-3" href="<?php echo e(url('report/dashboard')); ?>">Laporan</a>
        </div>
    </div>
</div>
<?php /**PATH /home/n1603557/public_html/e-lap/resources/views/pusat/section/sidebar.blade.php ENDPATH**/ ?>