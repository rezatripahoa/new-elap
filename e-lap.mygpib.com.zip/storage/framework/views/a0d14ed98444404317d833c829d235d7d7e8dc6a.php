<!DOCTYPE html>
<html>

<head>

    <title>Document</title>

    <meta property="og:title" content="eGrad.id" />
    <meta property="og:image" content="http://devnew.egrad.id/public/assets/images/favicon.png" />
    <meta property="og:description"
        content="eGrad Memberships Benefit. DISC Test. Up-to-date Job Vacancies Info. Digital Assessment Report. Automatically Will Enter into The Selection of Candidates." />
    <meta name="title" content="eGrad.id" />
    <meta name="description"
        content="eGrad Memberships Benefit. DISC Test. Up-to-date Job Vacancies Info. Digital Assessment Report. Automatically Will Enter into The Selection of Candidates." />

    <meta property="og:url" content="https://egrad.id/" />

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/favicon.png')); ?>" />

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
        integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

    <?php echo $__env->yieldContent('stylecss'); ?>
</head>

<body style="overflow-x:hidden;">

    <?php echo $__env->make('user/section/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="row" style="margin-top:20px;">
            <div class="col-12 col-md-3 bg-realblue p-3" style="margin-top: 50px;">
                <?php echo $__env->make('user/section/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-12 col-md-9">
                <?php if(Session::has('status')): ?>
                    <div class="alert alert-success mt-3 text-center">
                        <?php echo e(Session::get('status')); ?>

                        <?php
                            Session::forget('status');
                        ?>
                    </div>
                <?php endif; ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js"
        integrity="sha384-+YQ4JLhjyBLPDQt//I+STsc9iw4uQqACwlvpslubQzn4u2UU2UFM80nGisd026JF" crossorigin="anonymous">
    </script>

    <script type="text/javascript"></script>

    <?php echo $__env->yieldContent('footerjs'); ?>
</body>

</html>
<?php /**PATH /home/n1605061/public_html/e-lap.mygpib.com/resources/views/user/index.blade.php ENDPATH**/ ?>