<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Generate Laporan Narasi</title>
</head>
<style>
    * {
        padding: 10px;
        margin: 0px;
        font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
    }

    .p-0 {
        padding: 0;
    }

    .m-0 {
        margin: 0;
    }

    .mb-5 {
        margin-bottom: 5px;
    }

    .mt-20 {
        margin-top: 20px;
    }

    .page_break {
        page-break-before: always;
    }

    .img-width {
        width: 200px;
    }

    .header {
        margin-bottom: 20px;
    }

    h4 {
        font-weight: lighter;
    }

    div {
        border-top: 1px solid black;
        border-right: 1px solid black;
        border-left: 1px solid black;
        border-bottom: 0.5px solid black;
        margin: 0px;
        padding: 0px;
    }

    div h3 {
        border-bottom: 1px solid black;
        margin: 0px;
    }

    div h5 {
        font-size: 16px;
        border-bottom: 1px solid black;
        font-weight: normal;
        margin: 0px;
    }

    .realisasi {
        padding-left: 20px;
    }
</style>

<body>
    <center class="header">
        <h3 class="mb-5 p-0">LAPORAN KEGIATAN DAN KEUANGAN PROGRAM KERJA</h3>
        <h3 class="mb-5 p-0"><?php echo e(strtoupper($list->category[0]->category->category_name)); ?>

            (<?php echo e($list->category[0]->category->description); ?>)</h3>
        <h3 class="mb-5 p-0">TAHUN PROGRAM <?php echo e($list->year->year_name); ?></h3>
        <h3 class="mb-5 p-0"><?php echo e(strtoupper($department->department_name)); ?></h3>
    </center>

    <div>
        <h3>NAMA PROGRAM</h3>
        <h4><?php echo e($list->name); ?></h4>
    </div>

    <div>
        <h3>SIFAT PROGRAM</h3>
        <h4><?php echo e($list->type->name); ?></h4>
    </div>

    <div>
        <h3>TUJUAN PROGRAM</h3>
        <h4><?php echo e($list->tujuan); ?></h4>
    </div>

    <div>
        <h3>JADWAL KEGIATAN</h3>
        <h4><?php echo e(\Carbon\Carbon::parse($list->jadwal_start)->isoFormat('dddd, D MMMM Y')); ?></h4>
    </div>

    <div>
        <h3>LOKASI KEGIATAN</h3>
        <h4><?php echo e($list->lokasi); ?></h4>
    </div>

    <div>
        <h3>FREKUENSI KEGIATAN</h3>
        <h4><?php echo e($list->frekuensi); ?></h4>
    </div>

    <div>
        <h3>RENCANA ANGGARAN BIAYA</h3>
        <h3 class="realisasi">A. PENERIMAAN</h3>
        <h5 class="realisasi">IDR <?php echo e(number_format($list->rencana_penerimaan, 2, ',', '.')); ?></h5>
        <h3 class="realisasi">B. PENGELUARAN</h3>
        <h4 class="realisasi">IDR <?php echo e(number_format($list->rencana_pengeluaran, 2, ',', '.')); ?></h4>
    </div>
    <div>
        <h3>REALISASI ANGGARAN BIAYA</h3>
        <h3 class="realisasi">A. PENERIMAAN</h3>
        <h5 class="realisasi">IDR <?php echo e(number_format($list->realisasi_penerimaan, 2, ',', '.')); ?></h5>
        <h3 class="realisasi">B. PENGELUARAN</h3>
        <h4 class="realisasi">IDR <?php echo e(number_format($list->realisasi_pengeluaran, 2, ',', '.')); ?></h4>
    </div>
    <div>
        <h3>KETERANGAN</h3>
        <h4><?php echo e($list->keterangan); ?></h4>
    </div>

    <div class="page_break"></div>
    <h3 class="mb-5">(LAMPIRAN BUKTI PENERIMAAN & PENGELUARAN)</h3>
    <h3 class="mb-5">BUKTI PENERIMAAN :</h3>

    <?php $__currentLoopData = $list->attachment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($attachment->category == 2): ?>
            <h3><?php echo e($key + 1); ?>. <?php echo e($attachment->name); ?></h3>
            <img class="img-width" src="<?php echo e(url('assets/images/attachments/' . $list->id . '/' . $attachment->file)); ?>"
                alt="image">
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <h3 class="mb-5 mt-20">BUKTI PENGELUARAN :</h3>
    <?php $__currentLoopData = $list->attachment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys => $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($attachment->category == 1): ?>
            <h3><?php echo e($keys + 1); ?>. <?php echo e($attachment->name); ?></h3>
            <img class="img-width" src="<?php echo e(url('assets/images/attachments/' . $list->id . '/' . $attachment->file)); ?>"
                alt="image">
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>

</html>
<?php /**PATH D:\Development\e-lap.mygpib.com\e-lap.mygpib.com\resources\views/generate/laporan_program.blade.php ENDPATH**/ ?>