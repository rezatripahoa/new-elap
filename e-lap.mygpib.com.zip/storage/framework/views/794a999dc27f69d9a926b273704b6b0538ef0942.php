<?php $__env->startSection('content'); ?>
    <main>
        <p class="text-center text-secondary font-weight-bold h2 p-3">
            List Department
        </p>

        <div class="container my-2" style="min-height: 50vh">
            <div class="row mt-3">
                <div class="col-md-12">
                    <table id="tableData" class="table table-striped" style="width:100%">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Nama Department</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $no=1; ?>
                            <?php $__currentLoopData = $data['list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no); ?>.</td>
                                    <td><?php echo e($department->department_name); ?></td>
                                    <td align="center">
                                        <?php $year = date('Y') . ' - ' . date('Y') + 1; ?>
                                        <a class="btn btn-realblue" href="<?php echo e(url('report/list_report')); ?>/<?php echo e($department->id); ?>?year=<?php echo e($year); ?>">Lihat Laporan</a>
                                    </td>
                                </tr>
                                <?php $no++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pusat/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/n1605061/public_html/e-lap.mygpib.com/resources/views/pusat/list_department.blade.php ENDPATH**/ ?>