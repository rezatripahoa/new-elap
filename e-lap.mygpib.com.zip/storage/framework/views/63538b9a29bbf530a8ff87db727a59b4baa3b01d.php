<div class="bg-white rounded d-none d-md-block">
    <div class="p-3 h5 font-weight-bold">
        <div class="">
            <i class="fa fa-book" style="font-size:20px;"></i>
            <a class="text-dark ml-3" href="<?php echo e(url('user/talent_mapping')); ?>">Laporan</a>
        </div>
    </div>
</div>
<?php /**PATH E:\Laravel\Edocument\resources\views/user/section/sidebar.blade.php ENDPATH**/ ?>