<?php $__env->startSection('content'); ?>
    <main>
        <p class="text-center text-secondary font-weight-bold h2 p-3">
            List Laporan
        </p>

        <div class="p-2">
            <select class="form-select bg-realblue text-white p-2 font-weight-bold rounded" onchange="changeYear(this, <?php echo e($data['department']->id); ?>)">
                <?php $__currentLoopData = $data['year']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($year->year_name); ?>" <?php if($year->year_name == $data['curr_year']): ?> selected <?php endif; ?>>
                        <?php echo e($year->year_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="container my-2" style="min-height: 50vh">
            <div class="row mt-3">
                <div class="col-md-12">
                    <table id="tableData" class="table table-striped" style="width:100%">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Kategori</th>
                                <th>Tahun</th>
                                <th class="text-center">Laporan Narasi</th>
                                <th class="text-center">Laporan Matriks Excel</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $no=1; ?>
                            <?php $__currentLoopData = $data['category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $laporan = $data['list']->where('category_id', $category->id);
                                ?>
                                <tr>
                                    <td><?php echo e($no); ?>.</td>
                                    <td><?php echo e($category->category_name); ?></td>
                                    <td><?php echo e($data['curr_year']); ?></td>
                                    <td align="center">
                                        <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($val->document_name == 'LAPORAN KEGIATAN ' . $category->id . ' ' . $data['curr_year'] . ''): ?>
                                                <button data-toggle="modal" data-target="#lihatKegiatan_<?php echo e($val->id); ?>"
                                                    class="btn btn-realblue">Lihat</button>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td align="center">
                                        <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($val->document_name == 'LAPORAN KEUANGAN ' . $category->id . ' ' . $data['curr_year'] . ''): ?>
                                                <button data-toggle="modal" data-target="#lihatKeuangan_<?php echo e($val->id); ?>"
                                                    class="btn btn-realblue">Lihat</button>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                </tr>
                                <?php $no++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <?php $__currentLoopData = $data['list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- modal modalKegiatan -->
        <div class="modal fade" id="lihatKegiatan_<?php echo e($laporan->id); ?>" tabindex="-1" role="dialog"
            aria-labelledby="modalKegiatan_<?php echo e($laporan->id); ?>" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalKegiatan_<?php echo e($laporan->id); ?>">Laporan Narasi
                            <?php echo e($laporan->category->category_name); ?> <?php echo e($laporan->year->year_name); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <div class="d-flex justify-content-between w-100">
                            <label class="mb-1">Download Laporan Narasi</label>
                            <a target="_blank"
                                href="<?php echo e(asset('files/reports')); ?>/<?php echo e($data['department']->department_name); ?>/<?php echo e($laporan->document_file); ?>"
                                class="btn btn-realblue">Download</a>
                        </div>

                        <table class="table table-stripped my-3" id="tableKegiatan_1_2022">
                            <thead>
                                <tr>
                                    <th>Nama Lampiran</th>
                                    <th>File Lampiran</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $laporan->attachment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($attachment->attachment_name); ?></th>
                                        <th>
                                            <a target="_blank"
                                                href="<?php echo e(asset('files/reports')); ?>/<?php echo e($data['department']->department_name); ?>/<?php echo e($attachment->attachment_file); ?>"
                                                class="btn btn-realblue">Download</a>
                                        </th>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- end modal modalKegiatan -->

        <!-- modal modalKeuangan -->
        <div class="modal fade" id="lihatKeuangan_<?php echo e($laporan->id); ?>" tabindex="-1" role="dialog"
            aria-labelledby="lihatKeuangan_<?php echo e($laporan->id); ?>" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="lihatKeuangan_<?php echo e($laporan->id); ?>">Laporan Matriks Excel
                            <?php echo e($laporan->category->category_name); ?> <?php echo e($laporan->year->year_name); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <div class="d-flex justify-content-between w-100 mb-3">
                            <label class="mb-1">Download Laporan Matriks Excel</label>
                            <a target="_blank"
                                href="<?php echo e(asset('files/reports')); ?>/<?php echo e($data['department']->department_name); ?>/<?php echo e($laporan->document_file); ?>"
                                class="btn btn-realblue">Download</a>
                        </div>

                        
                    </div>
                </div>
            </div>
        </div>
        <!-- end modal modalKegiatan -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footerjs'); ?>
    <script>
        function addRow(e) {
            let target = $(e).attr('target');
            let html = ""
            html += "<tr>"
            html += `<td><input class="form-control" type="text" name="attachment_name[]"></td>`
            html +=
                `<td><input class="form-control-file" type="file" name="attachment_file[]" accept="image/*, application/pdf"></td>`
            html += `<td><button class="btn btn-danger" onclick="deleteRow(this)">Delete</button></td>`
            html += "</tr>"

            $('#' + target + ' tbody').append(html)
        }

        function deleteRow(e) {
            $(e).parent().parent().remove()
        }

        function changeYear(e, department_id){
            let year = e.value;
            window.location.href="<?php echo e(url('report/list_report')); ?>/"+department_id+"?year="+year
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/n1603557/public_html/e-lap/resources/views/admin/report/list_report.blade.php ENDPATH**/ ?>