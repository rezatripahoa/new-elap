<div class="bg-white rounded d-none d-md-block">
    <div class="p-3 h6 font-weight-bold">
        <div class="">
            <i class="fa fa-book" style="font-size:20px;"></i>
            <a class="text-dark ml-3" href="<?php echo e(url('admin/category')); ?>">Data Kategori</a>
        </div>
    </div>
</div>

<div class="bg-white rounded d-none d-md-block">
    <div class="p-3 h6 font-weight-bold">
        <div class="">
            <i class="fa fa-book" style="font-size:20px;"></i>
            <a class="text-dark ml-3" href="<?php echo e(url('admin/year')); ?>">Data Tahun</a>
        </div>
    </div>
</div>

<div class="bg-white rounded d-none d-md-block">
    <div class="p-3 h6 font-weight-bold">
        <div class="">
            <i class="fa fa-book" style="font-size:20px;"></i>
            <a class="text-dark ml-3" href="<?php echo e(url('admin/center')); ?>">Data Pusat</a>
        </div>
    </div>
</div>

<div class="bg-white rounded d-none d-md-block">
    <div class="p-3 h6 font-weight-bold">
        <div class="">
            <i class="fa fa-book" style="font-size:20px;"></i>
            <a class="text-dark ml-3" href="<?php echo e(url('admin/department')); ?>">Data Department</a>
        </div>
    </div>
</div>

<div class="bg-white rounded d-none d-md-block">
    <div class="p-3 h6 font-weight-bold">
        <div class="">
            <i class="fa fa-book" style="font-size:20px;"></i>
            <a class="text-dark ml-3" href="<?php echo e(url('admin/head')); ?>">Data Ketua Department</a>
        </div>
    </div>
</div>

<div class="bg-white rounded d-none d-md-block">
    <div class="p-3 h6 font-weight-bold">
        <div class="">
            <i class="fa fa-book" style="font-size:20px;"></i>
            <a class="text-dark ml-3" href="<?php echo e(url('admin/department_report')); ?>">Laporan</a>
        </div>
    </div>
</div>
<?php /**PATH /home/n1605061/public_html/e-lap.mygpib.com/resources/views/admin/section/sidebar.blade.php ENDPATH**/ ?>