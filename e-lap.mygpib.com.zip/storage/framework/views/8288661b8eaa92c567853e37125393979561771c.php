<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Kegiatan</title>

    <style>
        * {
            margin: 0px;
            padding: 0xp;
        }

        .container {
            width: 95%;
            margin: auto;
        }

        .w-100 {
            width: 100%;
        }

        .bold {
            font-weight: bold;
        }

        .title{
            font-weight: bold;
            margin-bottom: 10px;
        }

        table {
            border-spacing: 0;
        }
    </style>
</head>

<body>
    <div class="container">
        <center>
            <h2 class="title"><?php echo e(strtoupper($department->department_name)); ?></h2>
            <h2 class="title">LAPORAN REALISASI ANGGARAN TAHUN PROGRAM <?php echo e($year->year_name); ?></h2>
        </center>

        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <table border="1">
                <thead>
                    <tr>
                        <th rowspan="2" valign="middle" align="center" style="font-weight: bold;">NO</th>
                        <th rowspan="2" valign="middle" align="center" style="font-weight: bold;">NAMA PROGRAM</th>
                        <th rowspan="2" valign="middle" align="center" style="font-weight: bold;">TUJUAN</th>
                        <th rowspan="2" valign="middle" align="center" style="font-weight: bold;">JADWAL</th>
                        <th rowspan="2" valign="middle" align="center" style="font-weight: bold;">LOKASI</th>
                        <th rowspan="2" valign="middle" align="center" style="font-weight: bold;">FREKUENSI</th>
                        <th colspan="2" valign="middle" align="center" style="font-weight: bold;">RENCANA</th>
                        <th colspan="2" valign="middle" align="center" style="font-weight: bold;">REALISASI</th>
                        <th rowspan="2" valign="middle" align="center" style="font-weight: bold;">KETERANGAN</th>
                    </tr>
                    <tr>
                        <th valign="middle" align="center" style="font-weight: bold;">PENERIMAAN</th>
                        <th valign="middle" align="center" style="font-weight: bold;">PENGELUARAN</th>
                        <th valign="middle" align="center" style="font-weight: bold;">PENERIMAAN</th>
                        <th valign="middle" align="center" style="font-weight: bold;">PENGELUARAN</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $total_rencana_penerimaan = 0;
                        $total_rencana_pengeluaran = 0;
                        $total_realisasi_penerimaan = 0;
                        $total_realisasi_pengeluaran = 0;
                    ?>
                    <?php $no=1; ?>
                    <?php
                        $count_rutin = count(
                            array_filter($item->program_kerja_category->toArray(), function ($p) {
                                return $p['program_kerja']['type']['name'] == 'RUTIN';
                            }),
                        );
                    ?>
                    <?php if($count_rutin > 0): ?>
                        <tr class="break-type">
                            <td colspan="11" style="background-color: #7fff00; font-size: 20px; font-weight: bold;">
                                <h2>PROGRAM RUTIN</h2>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="11" align="center" style="font-weight: bold;">
                                <h5>PROGRAM RUTIN <?php echo e(strtoupper($item->category_name)); ?></h5>
                            </td>
                        </tr>
                    <?php endif; ?>
                    <?php $__currentLoopData = $item->program_kerja_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($val->program_kerja->type->name == 'RUTIN'): ?>
                            <tr>
                                <td><?php echo e($no); ?></td>
                                <td><?php echo e($val->program_kerja->name); ?></td>
                                <td><?php echo e($val->program_kerja->tujuan); ?></td>
                                <td><?php echo e($val->program_kerja->waktu); ?></td>
                                <td><?php echo e($val->program_kerja->lokasi); ?></td>
                                <td><?php echo e($val->program_kerja->frekuensi); ?></td>
                                <td data-format="Rp#,##0_-"><?php echo e($val->program_kerja->rencana_penerimaan); ?></td>
                                <td data-format="Rp#,##0_-"><?php echo e($val->program_kerja->rencana_pengeluaran); ?></td>
                                <td data-format="Rp#,##0_-"><?php echo e($val->program_kerja->realisasi_penerimaan); ?></td>
                                <td data-format="Rp#,##0_-"><?php echo e($val->program_kerja->realisasi_pengeluaran); ?></td>
                                <td><?php echo e($val->program_kerja->keterangan); ?></td>
                            </tr>
                            <?php $no++; ?>
                            <?php
                                $total_rencana_penerimaan += $val->program_kerja->rencana_penerimaan;
                                $total_rencana_pengeluaran += $val->program_kerja->rencana_pengeluaran;
                                $total_realisasi_penerimaan = $val->program_kerja->realisasi_penerimaan;
                                $total_realisasi_pengeluaran = $val->program_kerja->realisasi_pengeluaran;
                            ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php $no=1; ?>
                    <?php
                        $count_non_rutin = count(
                            array_filter($item->program_kerja_category->toArray(), function ($p) {
                                return $p['program_kerja']['type']['name'] == 'NON RUTIN';
                            }),
                        );
                    ?>
                    <?php if($count_non_rutin > 0): ?>
                        <tr class="break-type">
                            <td colspan="11" style="background-color: #7fff00; font-size: 20px; font-weight: bold;">
                                <h2>PROGRAM NON RUTIN</h2>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="11" align="center" style="font-weight: bold;">
                                <h5>PROGRAM NON RUTIN <?php echo e(strtoupper($item->category_name)); ?></h5>
                            </td>
                        </tr>
                    <?php endif; ?>
                    <?php $__currentLoopData = $item->program_kerja_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($val->program_kerja->type->name == 'NON RUTIN'): ?>
                            <tr>
                                <td><?php echo e($no); ?></td>
                                <td><?php echo e($val->program_kerja->name); ?></td>
                                <td><?php echo e($val->program_kerja->tujuan); ?></td>
                                <td><?php echo e($val->program_kerja->waktu); ?></td>
                                <td><?php echo e($val->program_kerja->lokasi); ?></td>
                                <td><?php echo e($val->program_kerja->frekuensi); ?></td>
                                <td data-format="Rp#,##0_-"><?php echo e($val->program_kerja->rencana_penerimaan); ?></td>
                                <td data-format="Rp#,##0_-"><?php echo e($val->program_kerja->rencana_pengeluaran); ?></td>
                                <td data-format="Rp#,##0_-"><?php echo e($val->program_kerja->realisasi_penerimaan); ?></td>
                                <td data-format="Rp#,##0_-"><?php echo e($val->program_kerja->realisasi_pengeluaran); ?></td>
                                <td><?php echo e($val->program_kerja->keterangan); ?></td>
                            </tr>
                            <?php $no++; ?>
                            <?php
                                $total_rencana_penerimaan += $val->program_kerja->rencana_penerimaan;
                                $total_rencana_pengeluaran += $val->program_kerja->rencana_pengeluaran;
                                $total_realisasi_penerimaan = $val->program_kerja->realisasi_penerimaan;
                                $total_realisasi_pengeluaran = $val->program_kerja->realisasi_pengeluaran;
                            ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php $no=1; ?>
                    <?php
                        $count_proyek = count(
                            array_filter($item->program_kerja_category->toArray(), function ($p) {
                                return $p['program_kerja']['type']['name'] == 'PROYEK';
                            }),
                        );
                    ?>
                    <?php if($count_proyek > 0): ?>
                        <tr class="break-type">
                            <td colspan="11" style="background-color: #7fff00; font-size: 20px; font-weight: bold;">
                                <h2>PROYEK</h2>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="11" align="center" style="font-weight: bold;">
                                <h5>PROYEK <?php echo e(strtoupper($item->category_name)); ?></h5>
                            </td>
                        </tr>
                    <?php endif; ?>
                    <?php $__currentLoopData = $item->program_kerja_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($val->program_kerja->type->name == 'PROYEK'): ?>
                            <tr>
                                <td><?php echo e($no); ?></td>
                                <td><?php echo e($val->program_kerja->name); ?></td>
                                <td><?php echo e($val->program_kerja->tujuan); ?></td>
                                <td><?php echo e($val->program_kerja->waktu); ?></td>
                                <td><?php echo e($val->program_kerja->lokasi); ?></td>
                                <td><?php echo e($val->program_kerja->frekuensi); ?></td>
                                <td data-format="Rp#,##0_-"><?php echo e($val->program_kerja->rencana_penerimaan); ?></td>
                                <td data-format="Rp#,##0_-"><?php echo e($val->program_kerja->rencana_pengeluaran); ?></td>
                                <td data-format="Rp#,##0_-"><?php echo e($val->program_kerja->realisasi_penerimaan); ?></td>
                                <td data-format="Rp#,##0_-"><?php echo e($val->program_kerja->realisasi_pengeluaran); ?></td>
                                <td><?php echo e($val->program_kerja->keterangan); ?></td>
                            </tr>
                            <?php $no++; ?>
                            <?php
                                $total_rencana_penerimaan += $val->program_kerja->rencana_penerimaan;
                                $total_rencana_pengeluaran += $val->program_kerja->rencana_pengeluaran;
                                $total_realisasi_penerimaan = $val->program_kerja->realisasi_penerimaan;
                                $total_realisasi_pengeluaran = $val->program_kerja->realisasi_pengeluaran;
                            ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr class="footer-total">
                        <td colspan="6" align="center"
                            style="font-size: 20px; font-weight: bold; background-color: #00ffff">
                            TOTAL <?php echo e(strtoupper($item->category_name)); ?>

                        </td>
                        <td data-format="Rp#,##0_-"
                            style="font-size: 20px; font-weight: bold; background-color: #00ffff">
                            <?php echo e($total_rencana_penerimaan); ?>

                        </td>
                        <td data-format="Rp#,##0_-"
                            style="font-size: 20px; font-weight: bold; background-color: #00ffff">
                            <?php echo e($total_rencana_pengeluaran); ?>

                        </td>
                        <td data-format="Rp#,##0_-"
                            style="font-size: 20px; font-weight: bold; background-color: #00ffff">
                            <?php echo e($total_realisasi_penerimaan); ?>

                        </td>
                        <td data-format="Rp#,##0_-"
                            style="font-size: 20px; font-weight: bold; background-color: #00ffff">
                            <?php echo e($total_realisasi_pengeluaran); ?>

                        </td>
                        <td data-format="Rp#,##0_-"
                            style="font-size: 20px; font-weight: bold; background-color: #00ffff">
                        </td>
                    </tr>
                </tbody>
            </table>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>

</html>
<?php /**PATH D:\Development\e-lap.mygpib.com\e-lap.mygpib.com\resources\views/generate/laporan_kegiatan_realisasi_pdf.blade.php ENDPATH**/ ?>