

<?php $__env->startSection('content'); ?>
    <main>
        <?php
            $url_triwulan_generate = 'laporan_triwulan_rpka_generate';
            $url_gabungan_generate = 'laporan_gabungan_rpka_generate';
            if (auth()->user()->role == 4) {
                $url_triwulan_generate = 'head/' . $url_triwulan_generate . '_head';
                $url_gabungan_generate = 'head/' . $url_gabungan_generate . '_head';
            } elseif (auth()->user()->role == 5) {
                $url_triwulan_generate = 'kabid/' . $url_triwulan_generate . '_kabid';
                $url_gabungan_generate = 'kabid/' . $url_gabungan_generate . '_kabid';
            } elseif (auth()->user()->role == 3) {
                $url_triwulan_generate = 'department/' . $url_triwulan_generate;
                $url_gabungan_generate = 'department/' . $url_gabungan_generate;
            }
        ?>
        <p class="text-center text-secondary font-weight-bold h2 p-3">
            Download RPKA
        </p>

        <div class="px-4">
            <div class="card">
                <div class="card-header">
                    Laporan Per Triwulan
                </div>
                <div class="card-body">
                    <form target="_blank" action="<?php echo e(url($url_triwulan_generate)); ?>" method="GET">
                        <div class="form-group">
                            <label>Pilih Tahun</label>
                            <select name="year" class="form-control">
                                <option>Pilih Tahun</option>
                                <?php $__currentLoopData = $data['year']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>">
                                        <?php echo e($item->year_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Pilih Fase Program</label>
                            <div>
                                <?php $__currentLoopData = $data['category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check form-check-inline">
                                        <input name="category[]" class="form-check-input" type="checkbox"
                                            value="<?php echo e($item->id); ?>">
                                        <label class="form-check-label"><?php echo e($item->category_name); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="form-group text-right">
                            <button class="btn btn-realblue" type="submit">Download</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card my-4">
                <div class="card-header">
                    Laporan Gabungan Per Tahun
                </div>
                <div class="card-body">
                    <form target="_blank" action="<?php echo e(url($url_gabungan_generate)); ?>" method="GET">
                        <div class="form-group">
                            <label>Pilih Tahun</label>
                            <select name="year" class="form-control">
                                <option>Pilih Tahun</option>
                                <?php $__currentLoopData = $data['year']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>">
                                        <?php echo e($item->year_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group text-right">
                            <button class="btn btn-realblue" type="submit">Download</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\e-lap.mygpib.com\e-lap.mygpib.com\resources\views/user/laporan_gabungan_rpka/index.blade.php ENDPATH**/ ?>