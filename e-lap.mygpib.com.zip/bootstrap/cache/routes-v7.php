<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sanctum.csrf-cookie',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/health-check' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.healthCheck',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/execute-solution' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.executeSolution',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/update-config' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.updateConfig',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/api-category' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api-category.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api-category.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/api-tahun' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api-tahun.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api-tahun.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::76mXRaE3c77nyQMS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RIccXlPW41h2jNfW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login_submit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wpE78arEfAEdi5NB',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WL9D9cRYRxlxya1R',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/change_password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZkciwY1P2vOIT0hh',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/change_password_submit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::76BByq9RDbUXhYb4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bK2HUG1jNykLaKjp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/category' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'category.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'category.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/category/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'category.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/year' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'year.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'year.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/year/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'year.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/center' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'center.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'center.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/center/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'center.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/department' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'department.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'department.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/department/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'department.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/head' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'head.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'head.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/head/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'head.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/commission' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'commission.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'commission.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/commission/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'commission.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/type' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'type.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'type.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/type/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'type.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/header_report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'header_report.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'header_report.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/header_report/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'header_report.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/ketua_bidang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ketua_bidang.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'ketua_bidang.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/ketua_bidang/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ketua_bidang.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/department_report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1q8TSicDu3MOI4Pz',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/report_program' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OtQBryNll4S0U2oN',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/report_gabungan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LlsbmgYdclsfYr7c',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/report/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tr8tCI7qsBwbhiVt',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/report/report_program_report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ad1iq0Rj33YD7F7C',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/report/program_kerja_report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_report.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_report.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/report/program_kerja_report/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_report.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/report/program_kerja_attachment_report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_attachment_report.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_attachment_report.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/report/program_kerja_attachment_report/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_attachment_report.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/department/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pyXLKubr2BvnmSWC',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/department/laporan_kegiatan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::r4JZaCeeboIObBfS',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1iIIPygerf5obfkn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/department/laporan_keuangan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NxtaH1kbvJtg0ea4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/department/program_kerja_acc' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jPwvTQqFyS0KKd1s',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/department/program_kerja_realisasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hsIcrKao7uBuaCIe',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/department/program_kerja' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/department/program_kerja/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/department/program_kerja_attachment' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_attachment.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_attachment.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/department/program_kerja_attachment/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_attachment.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/department/laporan_narasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4HYGXGwUX31uVtnZ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/department/laporan_gabungan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::evVqV8BIIp7whKZI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/department/laporan_gabungan_generate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tqQe320ttP5RfBpK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/department/laporan_triwulan_generate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9NGVGkHDm612Z7Ek',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/department/laporan_gabungan_rpka' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BwLeYKDAKa6uLqwb',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/department/laporan_gabungan_rpka_generate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NrGX9vCEzuM1HeDS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/department/laporan_triwulan_rpka_generate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::su8ilgPew9TpC3of',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/department/program-kerja-upload' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JtUBa4pvNcGK4aUu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/head/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jc1x5TvtEgVFMkdI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/head/program_kerja_acc_head' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dd5Fba5tp4Wv3Y17',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/head/program_kerja_realisasi_head' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1NQS4I3JRYKAA1ji',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/head/program_kerja_head' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_head.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_head.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/head/program_kerja_head/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_head.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/head/program_kerja_attachment_head' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_attachment_head.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_attachment_head.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/head/program_kerja_attachment_head/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_attachment_head.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/head/laporan_narasi_head' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IztB4qlcKGOM4Gls',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/head/laporan_kegiatan_head' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZJY7tbCdz0cbMRgc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/head/laporan_gabungan_head' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OE4y0tRgF00UW922',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/head/laporan_gabungan_generate_head' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oT0UUt6eiVYaG4Mx',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/head/laporan_triwulan_generate_head' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nGEbjdkgBisMspQo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/head/laporan_gabungan_rpka_head' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EMP9yvad6MAgffGh',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/head/laporan_gabungan_rpka_generate_head' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Zg278Rum6cNIFDpy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/head/laporan_triwulan_rpka_generate_head' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2VSzKzg7xk8F5tMS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kabid/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rWTIoWtloMP5knhr',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kabid/laporan_narasi_kabid' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WVh9tYvAW1quOJz2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kabid/laporan_kegiatan_kabid' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::b3Yl6YqFHa0ESF9C',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kabid/laporan_gabungan_kabid' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7G2KmdJBvYrT58We',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kabid/laporan_gabungan_generate_kabid' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Qu4dyuaYxmZTun8x',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kabid/laporan_triwulan_generate_kabid' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::59UrAz19A2BXEtld',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kabid/laporan_gabungan_rpka_kabid' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oH64s3TpaDw860sl',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kabid/laporan_gabungan_generate_rpka_kabid' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GCNQEqmNI0CFd6fR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kabid/laporan_triwulan_generate_rpka_kabid' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YgUNhHZb4mny6Gfg',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/a(?|pi/api\\-(?|category/([^/]++)(?|(*:43))|tahun/([^/]++)(?|(*:68)))|dmin/(?|c(?|ategory/([^/]++)(?|(*:108)|/edit(*:121)|(*:129))|enter/([^/]++)(?|(*:155)|/edit(*:168)|(*:176))|ommission/([^/]++)(?|(*:206)|/edit(*:219)|(*:227)))|year/([^/]++)(?|(*:253)|/edit(*:266)|(*:274))|department/([^/]++)(?|(*:305)|/edit(*:318)|(*:326))|head(?|/([^/]++)(?|(*:354)|/edit(*:367)|(*:375))|er_report/([^/]++)(?|(*:405)|/edit(*:418)|(*:426)))|type/([^/]++)(?|(*:452)|/edit(*:465)|(*:473))|ketua_bidang/([^/]++)(?|(*:506)|/edit(*:519)|(*:527))|report(?|/([^/]++)(*:554)|_(?|program(?|/([^/]++)(*:585)|_(?|narasi/([^/]++)(*:612)|kegiatan/([^/]++)(*:637)))|gabungan/([^/]++)(*:664)|triwulan/([^/]++)(*:689)|summary/([^/]++)(*:713)))|laporan_(?|narasi_(?|admin/([^/]++)(*:758)|generate_admin/([^/]++)/([^/]++)(*:798))|program_generate_admin/([^/]++)/([^/]++)(*:847)|gabungan_(?|admin/([^/]++)(*:881)|generate_admin/([^/]++)(*:912))|triwulan_generate_admin/([^/]++)(*:953))))|/report/(?|laporan_(?|kegiatan_admin_report/([^/]++)(*:1016)|narasi_(?|admin_report/([^/]++)(*:1056)|generate_admin_report/([^/]++)/([^/]++)(*:1104))|program_generate_admin_report/([^/]++)/([^/]++)(*:1161)|gabungan_(?|admin_report/([^/]++)(*:1203)|generate_report/([^/]++)(*:1236))|triwulan_generate_report/([^/]++)(*:1279))|program_kerja_(?|a(?|dmin_report/([^/]++)(*:1330)|ttachment_report/([^/]++)(?|(*:1367)|/edit(*:1381)|(*:1390)))|report/([^/]++)(?|(*:1419)|/edit(*:1433)|(*:1442))|excel_report/([^/]++)/([^/]++)(*:1482)|pdf_report/([^/]++)/([^/]++)(*:1519)))|/department/(?|program_kerja(?|_(?|a(?|cc/([^/]++)(*:1580)|ttachment/([^/]++)(?|(*:1610)|/edit(*:1624)|(*:1633)))|realisasi(?|/([^/]++)(?|(*:1668))|_(?|excel/([^/]++)(*:1696)|pdf/([^/]++)(*:1717)))|excel/([^/]++)(*:1742)|pdf/([^/]++)(*:1763))|/([^/]++)(?|(*:1785)|/edit(*:1799)|(*:1808)))|laporan_(?|narasi_generate/([^/]++)(*:1854)|program_generate/([^/]++)(*:1888)))|/head/(?|program_kerja_(?|a(?|cc_head/([^/]++)(*:1945)|ttachment_head/([^/]++)(?|(*:1980)|/edit(*:1994)|(*:2003)))|head/([^/]++)(?|(*:2030)|/edit(*:2044)|(*:2053))|excel_head/([^/]++)(*:2082)|pdf_head/([^/]++)(*:2108))|laporan_(?|narasi_generate_head/([^/]++)(*:2158)|program_generate_head/([^/]++)(*:2197)))|/kabid/laporan_(?|narasi_generate_kabid/([^/]++)(*:2256)|program_generate_kabid/([^/]++)(*:2296)))/?$}sDu',
    ),
    3 => 
    array (
      43 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api-category.show',
          ),
          1 => 
          array (
            0 => 'api_category',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api-category.update',
          ),
          1 => 
          array (
            0 => 'api_category',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api-category.destroy',
          ),
          1 => 
          array (
            0 => 'api_category',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      68 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api-tahun.show',
          ),
          1 => 
          array (
            0 => 'api_tahun',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'api-tahun.update',
          ),
          1 => 
          array (
            0 => 'api_tahun',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'api-tahun.destroy',
          ),
          1 => 
          array (
            0 => 'api_tahun',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      108 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'category.show',
          ),
          1 => 
          array (
            0 => 'category',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      121 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'category.edit',
          ),
          1 => 
          array (
            0 => 'category',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      129 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'category.update',
          ),
          1 => 
          array (
            0 => 'category',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'category.destroy',
          ),
          1 => 
          array (
            0 => 'category',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      155 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'center.show',
          ),
          1 => 
          array (
            0 => 'center',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      168 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'center.edit',
          ),
          1 => 
          array (
            0 => 'center',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      176 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'center.update',
          ),
          1 => 
          array (
            0 => 'center',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'center.destroy',
          ),
          1 => 
          array (
            0 => 'center',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      206 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'commission.show',
          ),
          1 => 
          array (
            0 => 'commission',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      219 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'commission.edit',
          ),
          1 => 
          array (
            0 => 'commission',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      227 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'commission.update',
          ),
          1 => 
          array (
            0 => 'commission',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'commission.destroy',
          ),
          1 => 
          array (
            0 => 'commission',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      253 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'year.show',
          ),
          1 => 
          array (
            0 => 'year',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      266 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'year.edit',
          ),
          1 => 
          array (
            0 => 'year',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      274 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'year.update',
          ),
          1 => 
          array (
            0 => 'year',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'year.destroy',
          ),
          1 => 
          array (
            0 => 'year',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      305 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'department.show',
          ),
          1 => 
          array (
            0 => 'department',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      318 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'department.edit',
          ),
          1 => 
          array (
            0 => 'department',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      326 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'department.update',
          ),
          1 => 
          array (
            0 => 'department',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'department.destroy',
          ),
          1 => 
          array (
            0 => 'department',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      354 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'head.show',
          ),
          1 => 
          array (
            0 => 'head',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      367 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'head.edit',
          ),
          1 => 
          array (
            0 => 'head',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      375 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'head.update',
          ),
          1 => 
          array (
            0 => 'head',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'head.destroy',
          ),
          1 => 
          array (
            0 => 'head',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      405 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'header_report.show',
          ),
          1 => 
          array (
            0 => 'header_report',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      418 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'header_report.edit',
          ),
          1 => 
          array (
            0 => 'header_report',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      426 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'header_report.update',
          ),
          1 => 
          array (
            0 => 'header_report',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'header_report.destroy',
          ),
          1 => 
          array (
            0 => 'header_report',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      452 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'type.show',
          ),
          1 => 
          array (
            0 => 'type',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      465 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'type.edit',
          ),
          1 => 
          array (
            0 => 'type',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      473 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'type.update',
          ),
          1 => 
          array (
            0 => 'type',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'type.destroy',
          ),
          1 => 
          array (
            0 => 'type',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      506 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ketua_bidang.show',
          ),
          1 => 
          array (
            0 => 'ketua_bidang',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      519 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ketua_bidang.edit',
          ),
          1 => 
          array (
            0 => 'ketua_bidang',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      527 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ketua_bidang.update',
          ),
          1 => 
          array (
            0 => 'ketua_bidang',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'ketua_bidang.destroy',
          ),
          1 => 
          array (
            0 => 'ketua_bidang',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      554 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CojjzoBUHrsyfHGa',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      585 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NxyDmg6cyPJ0G5vd',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      612 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7ouQEQCuoeSHa4Ya',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      637 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8C0F0c71wZez1Rfc',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      664 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6w5LzLPDh2ZHfs9m',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      689 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::61H5XwGX2QwTDIM4',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      713 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QzBsKZpfUG0gyuB9',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      758 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bab5sNJSee2G6taI',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      798 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eH2WDUuo7DcZbPOX',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'department',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      847 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hDQshH9l1jiw1AIu',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'department',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      881 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5f4VejSgQayqYlQH',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      912 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZSrftEnngBM7htE4',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      953 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bpDYiJ0eN4rOR2ks',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1016 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cL49oCRg472JUAEA',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1056 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Cly9hsKnjUKXiIDq',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1104 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Q6NlZQ8nfbit6hdv',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'department',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1161 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8nzQCN0JOTw4OsZ6',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'department',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1203 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Vz66OtHGbsMb1OJ0',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1236 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OtGYfa2IpnR9QTjT',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1279 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RctPBI9xk1n2pDyU',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1330 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RBWUM0tETcxp5gEq',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1367 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_attachment_report.show',
          ),
          1 => 
          array (
            0 => 'program_kerja_attachment_report',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1381 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_attachment_report.edit',
          ),
          1 => 
          array (
            0 => 'program_kerja_attachment_report',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1390 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_attachment_report.update',
          ),
          1 => 
          array (
            0 => 'program_kerja_attachment_report',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_attachment_report.destroy',
          ),
          1 => 
          array (
            0 => 'program_kerja_attachment_report',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1419 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_report.show',
          ),
          1 => 
          array (
            0 => 'program_kerja_report',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1433 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_report.edit',
          ),
          1 => 
          array (
            0 => 'program_kerja_report',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1442 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_report.update',
          ),
          1 => 
          array (
            0 => 'program_kerja_report',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_report.destroy',
          ),
          1 => 
          array (
            0 => 'program_kerja_report',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1482 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iS7LYYicYgSzU3ia',
          ),
          1 => 
          array (
            0 => 'departement_id',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1519 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yDjXyGw3laiBUAwk',
          ),
          1 => 
          array (
            0 => 'departement_id',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1580 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OuCOxlohky2Ql6OV',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1610 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_attachment.show',
          ),
          1 => 
          array (
            0 => 'program_kerja_attachment',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1624 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_attachment.edit',
          ),
          1 => 
          array (
            0 => 'program_kerja_attachment',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1633 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_attachment.update',
          ),
          1 => 
          array (
            0 => 'program_kerja_attachment',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_attachment.destroy',
          ),
          1 => 
          array (
            0 => 'program_kerja_attachment',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1668 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::c44WakEO37b1ICID',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bJlWobXhtxcNOwDn',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1696 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wnmJD9qe2v925mgj',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1717 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uU7sYaSST6OIvZCr',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1742 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SrNaivhuNCSgtC4h',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1763 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QjfYX4K2CfSNibtg',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1785 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja.show',
          ),
          1 => 
          array (
            0 => 'program_kerja',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1799 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja.edit',
          ),
          1 => 
          array (
            0 => 'program_kerja',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1808 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja.update',
          ),
          1 => 
          array (
            0 => 'program_kerja',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja.destroy',
          ),
          1 => 
          array (
            0 => 'program_kerja',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1854 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YLWz6Iw6lZ1onlGI',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1888 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f21eUdOvyOAdyu1G',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1945 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Wbvg17Wwj5g4MBu2',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1980 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_attachment_head.show',
          ),
          1 => 
          array (
            0 => 'program_kerja_attachment_head',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1994 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_attachment_head.edit',
          ),
          1 => 
          array (
            0 => 'program_kerja_attachment_head',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2003 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_attachment_head.update',
          ),
          1 => 
          array (
            0 => 'program_kerja_attachment_head',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_attachment_head.destroy',
          ),
          1 => 
          array (
            0 => 'program_kerja_attachment_head',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2030 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_head.show',
          ),
          1 => 
          array (
            0 => 'program_kerja_head',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2044 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_head.edit',
          ),
          1 => 
          array (
            0 => 'program_kerja_head',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2053 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_head.update',
          ),
          1 => 
          array (
            0 => 'program_kerja_head',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'program_kerja_head.destroy',
          ),
          1 => 
          array (
            0 => 'program_kerja_head',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2082 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::weET9CMT9cGwEgcU',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2108 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4K4AHynnRrwC8uCe',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2158 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zos2UpfSAXjWTUrH',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2197 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BiNQXz2QYkncnY7i',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2256 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f4ampBe275IjkbnD',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2296 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NvZiYzQgILCd8kft',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'sanctum.csrf-cookie' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'sanctum.csrf-cookie',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.healthCheck' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_ignition/health-check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController',
        'as' => 'ignition.healthCheck',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.executeSolution' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/execute-solution',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController',
        'as' => 'ignition.executeSolution',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.updateConfig' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/update-config',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController',
        'as' => 'ignition.updateConfig',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api-category.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/api-category',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'as' => 'api-category.index',
        'uses' => 'App\\Http\\Controllers\\Api\\CategoryApiController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CategoryApiController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api-category.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/api-category',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'as' => 'api-category.store',
        'uses' => 'App\\Http\\Controllers\\Api\\CategoryApiController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\CategoryApiController@store',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api-category.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/api-category/{api_category}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'as' => 'api-category.show',
        'uses' => 'App\\Http\\Controllers\\Api\\CategoryApiController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\CategoryApiController@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api-category.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/api-category/{api_category}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'as' => 'api-category.update',
        'uses' => 'App\\Http\\Controllers\\Api\\CategoryApiController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\CategoryApiController@update',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api-category.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/api-category/{api_category}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'as' => 'api-category.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\CategoryApiController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\CategoryApiController@destroy',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api-tahun.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/api-tahun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'as' => 'api-tahun.index',
        'uses' => 'App\\Http\\Controllers\\Api\\YearApiController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\YearApiController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api-tahun.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/api-tahun',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'as' => 'api-tahun.store',
        'uses' => 'App\\Http\\Controllers\\Api\\YearApiController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\YearApiController@store',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api-tahun.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/api-tahun/{api_tahun}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'as' => 'api-tahun.show',
        'uses' => 'App\\Http\\Controllers\\Api\\YearApiController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\YearApiController@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api-tahun.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/api-tahun/{api_tahun}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'as' => 'api-tahun.update',
        'uses' => 'App\\Http\\Controllers\\Api\\YearApiController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\YearApiController@update',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api-tahun.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/api-tahun/{api_tahun}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'as' => 'api-tahun.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\YearApiController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\YearApiController@destroy',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::76mXRaE3c77nyQMS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@index',
        'controller' => 'App\\Http\\Controllers\\AuthController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::76mXRaE3c77nyQMS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RIccXlPW41h2jNfW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@index',
        'controller' => 'App\\Http\\Controllers\\AuthController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::RIccXlPW41h2jNfW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wpE78arEfAEdi5NB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login_submit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@login_submit',
        'controller' => 'App\\Http\\Controllers\\AuthController@login_submit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::wpE78arEfAEdi5NB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WL9D9cRYRxlxya1R' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\AuthController@logout',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::WL9D9cRYRxlxya1R',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZkciwY1P2vOIT0hh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'change_password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@changePassword',
        'controller' => 'App\\Http\\Controllers\\AuthController@changePassword',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ZkciwY1P2vOIT0hh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::76BByq9RDbUXhYb4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'change_password_submit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@changePasswordSubmit',
        'controller' => 'App\\Http\\Controllers\\AuthController@changePasswordSubmit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::76BByq9RDbUXhYb4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bK2HUG1jNykLaKjp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@list_departement',
        'controller' => 'App\\Http\\Controllers\\ReportController@list_departement',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::bK2HUG1jNykLaKjp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'category.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/category',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'category.index',
        'uses' => 'App\\Http\\Controllers\\CategoryController@index',
        'controller' => 'App\\Http\\Controllers\\CategoryController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'category.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/category/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'category.create',
        'uses' => 'App\\Http\\Controllers\\CategoryController@create',
        'controller' => 'App\\Http\\Controllers\\CategoryController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'category.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/category',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'category.store',
        'uses' => 'App\\Http\\Controllers\\CategoryController@store',
        'controller' => 'App\\Http\\Controllers\\CategoryController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'category.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/category/{category}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'category.show',
        'uses' => 'App\\Http\\Controllers\\CategoryController@show',
        'controller' => 'App\\Http\\Controllers\\CategoryController@show',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'category.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/category/{category}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'category.edit',
        'uses' => 'App\\Http\\Controllers\\CategoryController@edit',
        'controller' => 'App\\Http\\Controllers\\CategoryController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'category.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/category/{category}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'category.update',
        'uses' => 'App\\Http\\Controllers\\CategoryController@update',
        'controller' => 'App\\Http\\Controllers\\CategoryController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'category.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/category/{category}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'category.destroy',
        'uses' => 'App\\Http\\Controllers\\CategoryController@destroy',
        'controller' => 'App\\Http\\Controllers\\CategoryController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'year.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/year',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'year.index',
        'uses' => 'App\\Http\\Controllers\\YearController@index',
        'controller' => 'App\\Http\\Controllers\\YearController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'year.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/year/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'year.create',
        'uses' => 'App\\Http\\Controllers\\YearController@create',
        'controller' => 'App\\Http\\Controllers\\YearController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'year.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/year',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'year.store',
        'uses' => 'App\\Http\\Controllers\\YearController@store',
        'controller' => 'App\\Http\\Controllers\\YearController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'year.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/year/{year}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'year.show',
        'uses' => 'App\\Http\\Controllers\\YearController@show',
        'controller' => 'App\\Http\\Controllers\\YearController@show',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'year.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/year/{year}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'year.edit',
        'uses' => 'App\\Http\\Controllers\\YearController@edit',
        'controller' => 'App\\Http\\Controllers\\YearController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'year.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/year/{year}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'year.update',
        'uses' => 'App\\Http\\Controllers\\YearController@update',
        'controller' => 'App\\Http\\Controllers\\YearController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'year.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/year/{year}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'year.destroy',
        'uses' => 'App\\Http\\Controllers\\YearController@destroy',
        'controller' => 'App\\Http\\Controllers\\YearController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'center.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/center',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'center.index',
        'uses' => 'App\\Http\\Controllers\\CenterController@index',
        'controller' => 'App\\Http\\Controllers\\CenterController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'center.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/center/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'center.create',
        'uses' => 'App\\Http\\Controllers\\CenterController@create',
        'controller' => 'App\\Http\\Controllers\\CenterController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'center.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/center',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'center.store',
        'uses' => 'App\\Http\\Controllers\\CenterController@store',
        'controller' => 'App\\Http\\Controllers\\CenterController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'center.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/center/{center}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'center.show',
        'uses' => 'App\\Http\\Controllers\\CenterController@show',
        'controller' => 'App\\Http\\Controllers\\CenterController@show',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'center.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/center/{center}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'center.edit',
        'uses' => 'App\\Http\\Controllers\\CenterController@edit',
        'controller' => 'App\\Http\\Controllers\\CenterController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'center.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/center/{center}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'center.update',
        'uses' => 'App\\Http\\Controllers\\CenterController@update',
        'controller' => 'App\\Http\\Controllers\\CenterController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'center.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/center/{center}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'center.destroy',
        'uses' => 'App\\Http\\Controllers\\CenterController@destroy',
        'controller' => 'App\\Http\\Controllers\\CenterController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'department.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/department',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'department.index',
        'uses' => 'App\\Http\\Controllers\\DepartmentController@index',
        'controller' => 'App\\Http\\Controllers\\DepartmentController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'department.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/department/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'department.create',
        'uses' => 'App\\Http\\Controllers\\DepartmentController@create',
        'controller' => 'App\\Http\\Controllers\\DepartmentController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'department.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/department',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'department.store',
        'uses' => 'App\\Http\\Controllers\\DepartmentController@store',
        'controller' => 'App\\Http\\Controllers\\DepartmentController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'department.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/department/{department}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'department.show',
        'uses' => 'App\\Http\\Controllers\\DepartmentController@show',
        'controller' => 'App\\Http\\Controllers\\DepartmentController@show',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'department.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/department/{department}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'department.edit',
        'uses' => 'App\\Http\\Controllers\\DepartmentController@edit',
        'controller' => 'App\\Http\\Controllers\\DepartmentController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'department.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/department/{department}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'department.update',
        'uses' => 'App\\Http\\Controllers\\DepartmentController@update',
        'controller' => 'App\\Http\\Controllers\\DepartmentController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'department.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/department/{department}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'department.destroy',
        'uses' => 'App\\Http\\Controllers\\DepartmentController@destroy',
        'controller' => 'App\\Http\\Controllers\\DepartmentController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'head.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/head',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'head.index',
        'uses' => 'App\\Http\\Controllers\\HeadController@index',
        'controller' => 'App\\Http\\Controllers\\HeadController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'head.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/head/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'head.create',
        'uses' => 'App\\Http\\Controllers\\HeadController@create',
        'controller' => 'App\\Http\\Controllers\\HeadController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'head.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/head',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'head.store',
        'uses' => 'App\\Http\\Controllers\\HeadController@store',
        'controller' => 'App\\Http\\Controllers\\HeadController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'head.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/head/{head}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'head.show',
        'uses' => 'App\\Http\\Controllers\\HeadController@show',
        'controller' => 'App\\Http\\Controllers\\HeadController@show',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'head.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/head/{head}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'head.edit',
        'uses' => 'App\\Http\\Controllers\\HeadController@edit',
        'controller' => 'App\\Http\\Controllers\\HeadController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'head.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/head/{head}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'head.update',
        'uses' => 'App\\Http\\Controllers\\HeadController@update',
        'controller' => 'App\\Http\\Controllers\\HeadController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'head.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/head/{head}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'head.destroy',
        'uses' => 'App\\Http\\Controllers\\HeadController@destroy',
        'controller' => 'App\\Http\\Controllers\\HeadController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'commission.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/commission',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'commission.index',
        'uses' => 'App\\Http\\Controllers\\CommissionController@index',
        'controller' => 'App\\Http\\Controllers\\CommissionController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'commission.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/commission/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'commission.create',
        'uses' => 'App\\Http\\Controllers\\CommissionController@create',
        'controller' => 'App\\Http\\Controllers\\CommissionController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'commission.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/commission',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'commission.store',
        'uses' => 'App\\Http\\Controllers\\CommissionController@store',
        'controller' => 'App\\Http\\Controllers\\CommissionController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'commission.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/commission/{commission}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'commission.show',
        'uses' => 'App\\Http\\Controllers\\CommissionController@show',
        'controller' => 'App\\Http\\Controllers\\CommissionController@show',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'commission.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/commission/{commission}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'commission.edit',
        'uses' => 'App\\Http\\Controllers\\CommissionController@edit',
        'controller' => 'App\\Http\\Controllers\\CommissionController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'commission.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/commission/{commission}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'commission.update',
        'uses' => 'App\\Http\\Controllers\\CommissionController@update',
        'controller' => 'App\\Http\\Controllers\\CommissionController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'commission.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/commission/{commission}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'commission.destroy',
        'uses' => 'App\\Http\\Controllers\\CommissionController@destroy',
        'controller' => 'App\\Http\\Controllers\\CommissionController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'type.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/type',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'type.index',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaTypeController@index',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaTypeController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'type.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/type/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'type.create',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaTypeController@create',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaTypeController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'type.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/type',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'type.store',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaTypeController@store',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaTypeController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'type.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/type/{type}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'type.show',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaTypeController@show',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaTypeController@show',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'type.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/type/{type}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'type.edit',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaTypeController@edit',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaTypeController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'type.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/type/{type}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'type.update',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaTypeController@update',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaTypeController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'type.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/type/{type}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'type.destroy',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaTypeController@destroy',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaTypeController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'header_report.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/header_report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'header_report.index',
        'uses' => 'App\\Http\\Controllers\\HeaderReportController@index',
        'controller' => 'App\\Http\\Controllers\\HeaderReportController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'header_report.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/header_report/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'header_report.create',
        'uses' => 'App\\Http\\Controllers\\HeaderReportController@create',
        'controller' => 'App\\Http\\Controllers\\HeaderReportController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'header_report.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/header_report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'header_report.store',
        'uses' => 'App\\Http\\Controllers\\HeaderReportController@store',
        'controller' => 'App\\Http\\Controllers\\HeaderReportController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'header_report.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/header_report/{header_report}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'header_report.show',
        'uses' => 'App\\Http\\Controllers\\HeaderReportController@show',
        'controller' => 'App\\Http\\Controllers\\HeaderReportController@show',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'header_report.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/header_report/{header_report}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'header_report.edit',
        'uses' => 'App\\Http\\Controllers\\HeaderReportController@edit',
        'controller' => 'App\\Http\\Controllers\\HeaderReportController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'header_report.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/header_report/{header_report}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'header_report.update',
        'uses' => 'App\\Http\\Controllers\\HeaderReportController@update',
        'controller' => 'App\\Http\\Controllers\\HeaderReportController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'header_report.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/header_report/{header_report}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'header_report.destroy',
        'uses' => 'App\\Http\\Controllers\\HeaderReportController@destroy',
        'controller' => 'App\\Http\\Controllers\\HeaderReportController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ketua_bidang.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/ketua_bidang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'ketua_bidang.index',
        'uses' => 'App\\Http\\Controllers\\KetuaBidangController@index',
        'controller' => 'App\\Http\\Controllers\\KetuaBidangController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ketua_bidang.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/ketua_bidang/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'ketua_bidang.create',
        'uses' => 'App\\Http\\Controllers\\KetuaBidangController@create',
        'controller' => 'App\\Http\\Controllers\\KetuaBidangController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ketua_bidang.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/ketua_bidang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'ketua_bidang.store',
        'uses' => 'App\\Http\\Controllers\\KetuaBidangController@store',
        'controller' => 'App\\Http\\Controllers\\KetuaBidangController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ketua_bidang.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/ketua_bidang/{ketua_bidang}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'ketua_bidang.show',
        'uses' => 'App\\Http\\Controllers\\KetuaBidangController@show',
        'controller' => 'App\\Http\\Controllers\\KetuaBidangController@show',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ketua_bidang.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/ketua_bidang/{ketua_bidang}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'ketua_bidang.edit',
        'uses' => 'App\\Http\\Controllers\\KetuaBidangController@edit',
        'controller' => 'App\\Http\\Controllers\\KetuaBidangController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ketua_bidang.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/ketua_bidang/{ketua_bidang}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'ketua_bidang.update',
        'uses' => 'App\\Http\\Controllers\\KetuaBidangController@update',
        'controller' => 'App\\Http\\Controllers\\KetuaBidangController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ketua_bidang.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/ketua_bidang/{ketua_bidang}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'as' => 'ketua_bidang.destroy',
        'uses' => 'App\\Http\\Controllers\\KetuaBidangController@destroy',
        'controller' => 'App\\Http\\Controllers\\KetuaBidangController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1q8TSicDu3MOI4Pz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/department_report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@index',
        'controller' => 'App\\Http\\Controllers\\ReportController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::1q8TSicDu3MOI4Pz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CojjzoBUHrsyfHGa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report',
        'controller' => 'App\\Http\\Controllers\\ReportController@report',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::CojjzoBUHrsyfHGa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OtQBryNll4S0U2oN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report_program',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@list_departement',
        'controller' => 'App\\Http\\Controllers\\ReportController@list_departement',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::OtQBryNll4S0U2oN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NxyDmg6cyPJ0G5vd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report_program/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@list_report',
        'controller' => 'App\\Http\\Controllers\\ReportController@list_report',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::NxyDmg6cyPJ0G5vd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7ouQEQCuoeSHa4Ya' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report_program_narasi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_program_narasi',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_program_narasi',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::7ouQEQCuoeSHa4Ya',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8C0F0c71wZez1Rfc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report_program_kegiatan/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_program_kegiatan',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_program_kegiatan',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::8C0F0c71wZez1Rfc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bab5sNJSee2G6taI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/laporan_narasi_admin/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_narasi_admin',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_narasi_admin',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::bab5sNJSee2G6taI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eH2WDUuo7DcZbPOX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/laporan_narasi_generate_admin/{id}/{department}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_narasi_generate_admin',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_narasi_generate_admin',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::eH2WDUuo7DcZbPOX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hDQshH9l1jiw1AIu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/laporan_program_generate_admin/{id}/{department}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_laporan_generate_admin',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_laporan_generate_admin',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::hDQshH9l1jiw1AIu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5f4VejSgQayqYlQH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/laporan_gabungan_admin/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_gabungan_admin',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_gabungan_admin',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::5f4VejSgQayqYlQH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZSrftEnngBM7htE4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/laporan_gabungan_generate_admin/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_gabungan_excel_admin',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_gabungan_excel_admin',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::ZSrftEnngBM7htE4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bpDYiJ0eN4rOR2ks' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/laporan_triwulan_generate_admin/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_triwulan_excel_admin',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_triwulan_excel_admin',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::bpDYiJ0eN4rOR2ks',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LlsbmgYdclsfYr7c' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report_gabungan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_gabungan_index',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_gabungan_index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::LlsbmgYdclsfYr7c',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6w5LzLPDh2ZHfs9m' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report_gabungan/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_gabungan',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_gabungan',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::6w5LzLPDh2ZHfs9m',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::61H5XwGX2QwTDIM4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report_triwulan/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_triwulan',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_triwulan',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::61H5XwGX2QwTDIM4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QzBsKZpfUG0gyuB9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/report_summary/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:1',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_summary',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_summary',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::QzBsKZpfUG0gyuB9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tr8tCI7qsBwbhiVt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'report/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@list_departement',
        'controller' => 'App\\Http\\Controllers\\ReportController@list_departement',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
        'as' => 'generated::tr8tCI7qsBwbhiVt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ad1iq0Rj33YD7F7C' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'report/report_program_report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@list_departement',
        'controller' => 'App\\Http\\Controllers\\ReportController@list_departement',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
        'as' => 'generated::Ad1iq0Rj33YD7F7C',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cL49oCRg472JUAEA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'report/laporan_kegiatan_admin_report/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_kegiatan_admin',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_kegiatan_admin',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
        'as' => 'generated::cL49oCRg472JUAEA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Cly9hsKnjUKXiIDq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'report/laporan_narasi_admin_report/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_narasi_admin',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_narasi_admin',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
        'as' => 'generated::Cly9hsKnjUKXiIDq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Q6NlZQ8nfbit6hdv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'report/laporan_narasi_generate_admin_report/{id}/{department}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_narasi_generate_admin',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_narasi_generate_admin',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
        'as' => 'generated::Q6NlZQ8nfbit6hdv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8nzQCN0JOTw4OsZ6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'report/laporan_program_generate_admin_report/{id}/{department}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_laporan_generate_admin',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_laporan_generate_admin',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
        'as' => 'generated::8nzQCN0JOTw4OsZ6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Vz66OtHGbsMb1OJ0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'report/laporan_gabungan_admin_report/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_gabungan_admin',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_gabungan_admin',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
        'as' => 'generated::Vz66OtHGbsMb1OJ0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OtGYfa2IpnR9QTjT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'report/laporan_gabungan_generate_report/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_gabungan_excel_admin',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_gabungan_excel_admin',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
        'as' => 'generated::OtGYfa2IpnR9QTjT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RctPBI9xk1n2pDyU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'report/laporan_triwulan_generate_report/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_triwulan_excel_admin',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_triwulan_excel_admin',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
        'as' => 'generated::RctPBI9xk1n2pDyU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RBWUM0tETcxp5gEq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'report/program_kerja_admin_report/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@program_kerja_acc_admin',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@program_kerja_acc_admin',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
        'as' => 'generated::RBWUM0tETcxp5gEq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_report.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'report/program_kerja_report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'as' => 'program_kerja_report.index',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@index',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@index',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_report.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'report/program_kerja_report/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'as' => 'program_kerja_report.create',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@create',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@create',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_report.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'report/program_kerja_report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'as' => 'program_kerja_report.store',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@store',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@store',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_report.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'report/program_kerja_report/{program_kerja_report}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'as' => 'program_kerja_report.show',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@show',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@show',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_report.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'report/program_kerja_report/{program_kerja_report}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'as' => 'program_kerja_report.edit',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@edit',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@edit',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_report.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'report/program_kerja_report/{program_kerja_report}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'as' => 'program_kerja_report.update',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@update',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@update',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_report.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'report/program_kerja_report/{program_kerja_report}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'as' => 'program_kerja_report.destroy',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@destroy',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@destroy',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_attachment_report.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'report/program_kerja_attachment_report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'as' => 'program_kerja_attachment_report.index',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@index',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@index',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_attachment_report.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'report/program_kerja_attachment_report/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'as' => 'program_kerja_attachment_report.create',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@create',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@create',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_attachment_report.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'report/program_kerja_attachment_report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'as' => 'program_kerja_attachment_report.store',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@store',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@store',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_attachment_report.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'report/program_kerja_attachment_report/{program_kerja_attachment_report}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'as' => 'program_kerja_attachment_report.show',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@show',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@show',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_attachment_report.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'report/program_kerja_attachment_report/{program_kerja_attachment_report}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'as' => 'program_kerja_attachment_report.edit',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@edit',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@edit',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_attachment_report.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'report/program_kerja_attachment_report/{program_kerja_attachment_report}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'as' => 'program_kerja_attachment_report.update',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@update',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@update',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_attachment_report.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'report/program_kerja_attachment_report/{program_kerja_attachment_report}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'as' => 'program_kerja_attachment_report.destroy',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@destroy',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@destroy',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iS7LYYicYgSzU3ia' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'report/program_kerja_excel_report/{departement_id}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@program_kerja_excel_admin',
        'controller' => 'App\\Http\\Controllers\\ReportController@program_kerja_excel_admin',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
        'as' => 'generated::iS7LYYicYgSzU3ia',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yDjXyGw3laiBUAwk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'report/program_kerja_pdf_report/{departement_id}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:2',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@program_kerja_pdf_admin',
        'controller' => 'App\\Http\\Controllers\\ReportController@program_kerja_pdf_admin',
        'namespace' => NULL,
        'prefix' => '/report',
        'where' => 
        array (
        ),
        'as' => 'generated::yDjXyGw3laiBUAwk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pyXLKubr2BvnmSWC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@index',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@index',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::pyXLKubr2BvnmSWC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::r4JZaCeeboIObBfS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'department/laporan_kegiatan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\FrontUserController@laporan_kegiatan_submit',
        'controller' => 'App\\Http\\Controllers\\FrontUserController@laporan_kegiatan_submit',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::r4JZaCeeboIObBfS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NxtaH1kbvJtg0ea4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'department/laporan_keuangan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\FrontUserController@laporan_keuangan_submit',
        'controller' => 'App\\Http\\Controllers\\FrontUserController@laporan_keuangan_submit',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::NxtaH1kbvJtg0ea4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jPwvTQqFyS0KKd1s' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/program_kerja_acc',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@program_kerja_acc',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@program_kerja_acc',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::jPwvTQqFyS0KKd1s',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OuCOxlohky2Ql6OV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/program_kerja_acc/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@program_kerja_acc_submit',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@program_kerja_acc_submit',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::OuCOxlohky2Ql6OV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hsIcrKao7uBuaCIe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/program_kerja_realisasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@program_kerja_realisasi',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@program_kerja_realisasi',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::hsIcrKao7uBuaCIe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::c44WakEO37b1ICID' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/program_kerja_realisasi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@show_realisasi',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@show_realisasi',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::c44WakEO37b1ICID',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bJlWobXhtxcNOwDn' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'department/program_kerja_realisasi/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@program_kerja_realisasi_update',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@program_kerja_realisasi_update',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::bJlWobXhtxcNOwDn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/program_kerja',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'as' => 'program_kerja.index',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@index',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@index',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/program_kerja/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'as' => 'program_kerja.create',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@create',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@create',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'department/program_kerja',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'as' => 'program_kerja.store',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@store',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@store',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/program_kerja/{program_kerja}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'as' => 'program_kerja.show',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@show',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@show',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/program_kerja/{program_kerja}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'as' => 'program_kerja.edit',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@edit',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@edit',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'department/program_kerja/{program_kerja}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'as' => 'program_kerja.update',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@update',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@update',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'department/program_kerja/{program_kerja}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'as' => 'program_kerja.destroy',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@destroy',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@destroy',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_attachment.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/program_kerja_attachment',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'as' => 'program_kerja_attachment.index',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@index',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@index',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_attachment.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/program_kerja_attachment/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'as' => 'program_kerja_attachment.create',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@create',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@create',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_attachment.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'department/program_kerja_attachment',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'as' => 'program_kerja_attachment.store',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@store',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@store',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_attachment.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/program_kerja_attachment/{program_kerja_attachment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'as' => 'program_kerja_attachment.show',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@show',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@show',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_attachment.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/program_kerja_attachment/{program_kerja_attachment}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'as' => 'program_kerja_attachment.edit',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@edit',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@edit',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_attachment.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'department/program_kerja_attachment/{program_kerja_attachment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'as' => 'program_kerja_attachment.update',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@update',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@update',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_attachment.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'department/program_kerja_attachment/{program_kerja_attachment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'as' => 'program_kerja_attachment.destroy',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@destroy',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@destroy',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4HYGXGwUX31uVtnZ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/laporan_narasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_narasi',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_narasi',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::4HYGXGwUX31uVtnZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1iIIPygerf5obfkn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/laporan_kegiatan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_kegiatan',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_kegiatan',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::1iIIPygerf5obfkn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YLWz6Iw6lZ1onlGI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/laporan_narasi_generate/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_narasi_generate',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_narasi_generate',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::YLWz6Iw6lZ1onlGI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::f21eUdOvyOAdyu1G' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/laporan_program_generate/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_program_generate',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_program_generate',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::f21eUdOvyOAdyu1G',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::evVqV8BIIp7whKZI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/laporan_gabungan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_gabungan',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_gabungan',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::evVqV8BIIp7whKZI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tqQe320ttP5RfBpK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/laporan_gabungan_generate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_gabungan_excel',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_gabungan_excel',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::tqQe320ttP5RfBpK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9NGVGkHDm612Z7Ek' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/laporan_triwulan_generate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_triwulan_excel',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_triwulan_excel',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::9NGVGkHDm612Z7Ek',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BwLeYKDAKa6uLqwb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/laporan_gabungan_rpka',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_gabungan_rpka',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_gabungan_rpka',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::BwLeYKDAKa6uLqwb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NrGX9vCEzuM1HeDS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/laporan_gabungan_rpka_generate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_gabungan_rpka_excel',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_gabungan_rpka_excel',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::NrGX9vCEzuM1HeDS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::su8ilgPew9TpC3of' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/laporan_triwulan_rpka_generate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_triwulan_rpka_excel',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_triwulan_rpka_excel',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::su8ilgPew9TpC3of',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SrNaivhuNCSgtC4h' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/program_kerja_excel/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@program_kerja_excel',
        'controller' => 'App\\Http\\Controllers\\ReportController@program_kerja_excel',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::SrNaivhuNCSgtC4h',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QjfYX4K2CfSNibtg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/program_kerja_pdf/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@program_kerja_pdf',
        'controller' => 'App\\Http\\Controllers\\ReportController@program_kerja_pdf',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::QjfYX4K2CfSNibtg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wnmJD9qe2v925mgj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/program_kerja_realisasi_excel/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@program_kerja_realisasi_excel',
        'controller' => 'App\\Http\\Controllers\\ReportController@program_kerja_realisasi_excel',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::wnmJD9qe2v925mgj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uU7sYaSST6OIvZCr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'department/program_kerja_realisasi_pdf/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@program_kerja_realisasi_pdf',
        'controller' => 'App\\Http\\Controllers\\ReportController@program_kerja_realisasi_pdf',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::uU7sYaSST6OIvZCr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JtUBa4pvNcGK4aUu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'department/program-kerja-upload',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:3',
        ),
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@importFromExcel',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@importFromExcel',
        'namespace' => NULL,
        'prefix' => '/department',
        'where' => 
        array (
        ),
        'as' => 'generated::JtUBa4pvNcGK4aUu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jc1x5TvtEgVFMkdI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@index',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@index',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
        'as' => 'generated::jc1x5TvtEgVFMkdI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dd5Fba5tp4Wv3Y17' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/program_kerja_acc_head',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@program_kerja_acc',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@program_kerja_acc',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
        'as' => 'generated::dd5Fba5tp4Wv3Y17',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Wbvg17Wwj5g4MBu2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/program_kerja_acc_head/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@program_kerja_acc_submit',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@program_kerja_acc_submit',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
        'as' => 'generated::Wbvg17Wwj5g4MBu2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1NQS4I3JRYKAA1ji' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/program_kerja_realisasi_head',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@program_kerja_realisasi',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@program_kerja_realisasi',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
        'as' => 'generated::1NQS4I3JRYKAA1ji',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_head.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/program_kerja_head',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'as' => 'program_kerja_head.index',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@index',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@index',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_head.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/program_kerja_head/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'as' => 'program_kerja_head.create',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@create',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@create',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_head.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'head/program_kerja_head',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'as' => 'program_kerja_head.store',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@store',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@store',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_head.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/program_kerja_head/{program_kerja_head}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'as' => 'program_kerja_head.show',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@show',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@show',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_head.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/program_kerja_head/{program_kerja_head}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'as' => 'program_kerja_head.edit',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@edit',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@edit',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_head.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'head/program_kerja_head/{program_kerja_head}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'as' => 'program_kerja_head.update',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@update',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@update',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_head.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'head/program_kerja_head/{program_kerja_head}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'as' => 'program_kerja_head.destroy',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaController@destroy',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaController@destroy',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_attachment_head.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/program_kerja_attachment_head',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'as' => 'program_kerja_attachment_head.index',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@index',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@index',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_attachment_head.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/program_kerja_attachment_head/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'as' => 'program_kerja_attachment_head.create',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@create',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@create',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_attachment_head.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'head/program_kerja_attachment_head',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'as' => 'program_kerja_attachment_head.store',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@store',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@store',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_attachment_head.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/program_kerja_attachment_head/{program_kerja_attachment_head}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'as' => 'program_kerja_attachment_head.show',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@show',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@show',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_attachment_head.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/program_kerja_attachment_head/{program_kerja_attachment_head}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'as' => 'program_kerja_attachment_head.edit',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@edit',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@edit',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_attachment_head.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'head/program_kerja_attachment_head/{program_kerja_attachment_head}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'as' => 'program_kerja_attachment_head.update',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@update',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@update',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'program_kerja_attachment_head.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'head/program_kerja_attachment_head/{program_kerja_attachment_head}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'as' => 'program_kerja_attachment_head.destroy',
        'uses' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@destroy',
        'controller' => 'App\\Http\\Controllers\\ProgramKerjaReportAttachmentController@destroy',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IztB4qlcKGOM4Gls' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/laporan_narasi_head',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_narasi',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_narasi',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
        'as' => 'generated::IztB4qlcKGOM4Gls',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZJY7tbCdz0cbMRgc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/laporan_kegiatan_head',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_kegiatan',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_kegiatan',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
        'as' => 'generated::ZJY7tbCdz0cbMRgc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zos2UpfSAXjWTUrH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/laporan_narasi_generate_head/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_narasi_generate',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_narasi_generate',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
        'as' => 'generated::zos2UpfSAXjWTUrH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BiNQXz2QYkncnY7i' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/laporan_program_generate_head/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_program_generate',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_program_generate',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
        'as' => 'generated::BiNQXz2QYkncnY7i',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OE4y0tRgF00UW922' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/laporan_gabungan_head',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_gabungan',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_gabungan',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
        'as' => 'generated::OE4y0tRgF00UW922',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oT0UUt6eiVYaG4Mx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/laporan_gabungan_generate_head',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_gabungan_excel',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_gabungan_excel',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
        'as' => 'generated::oT0UUt6eiVYaG4Mx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nGEbjdkgBisMspQo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/laporan_triwulan_generate_head',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_triwulan_excel',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_triwulan_excel',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
        'as' => 'generated::nGEbjdkgBisMspQo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EMP9yvad6MAgffGh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/laporan_gabungan_rpka_head',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_gabungan_rpka',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_gabungan_rpka',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
        'as' => 'generated::EMP9yvad6MAgffGh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Zg278Rum6cNIFDpy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/laporan_gabungan_rpka_generate_head',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_gabungan_rpka_excel',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_gabungan_rpka_excel',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
        'as' => 'generated::Zg278Rum6cNIFDpy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2VSzKzg7xk8F5tMS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/laporan_triwulan_rpka_generate_head',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_triwulan_rpka_excel',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_triwulan_rpka_excel',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
        'as' => 'generated::2VSzKzg7xk8F5tMS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::weET9CMT9cGwEgcU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/program_kerja_excel_head/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@program_kerja_excel',
        'controller' => 'App\\Http\\Controllers\\ReportController@program_kerja_excel',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
        'as' => 'generated::weET9CMT9cGwEgcU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4K4AHynnRrwC8uCe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'head/program_kerja_pdf_head/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:4',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@program_kerja_pdf',
        'controller' => 'App\\Http\\Controllers\\ReportController@program_kerja_pdf',
        'namespace' => NULL,
        'prefix' => '/head',
        'where' => 
        array (
        ),
        'as' => 'generated::4K4AHynnRrwC8uCe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rWTIoWtloMP5knhr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kabid/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:5',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@index_kabid',
        'controller' => 'App\\Http\\Controllers\\ReportController@index_kabid',
        'namespace' => NULL,
        'prefix' => '/kabid',
        'where' => 
        array (
        ),
        'as' => 'generated::rWTIoWtloMP5knhr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WVh9tYvAW1quOJz2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kabid/laporan_narasi_kabid',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:5',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_narasi',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_narasi',
        'namespace' => NULL,
        'prefix' => '/kabid',
        'where' => 
        array (
        ),
        'as' => 'generated::WVh9tYvAW1quOJz2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::b3Yl6YqFHa0ESF9C' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kabid/laporan_kegiatan_kabid',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:5',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_narasi',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_narasi',
        'namespace' => NULL,
        'prefix' => '/kabid',
        'where' => 
        array (
        ),
        'as' => 'generated::b3Yl6YqFHa0ESF9C',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::f4ampBe275IjkbnD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kabid/laporan_narasi_generate_kabid/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:5',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_narasi_generate',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_narasi_generate',
        'namespace' => NULL,
        'prefix' => '/kabid',
        'where' => 
        array (
        ),
        'as' => 'generated::f4ampBe275IjkbnD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NvZiYzQgILCd8kft' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kabid/laporan_program_generate_kabid/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:5',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_program_generate',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_program_generate',
        'namespace' => NULL,
        'prefix' => '/kabid',
        'where' => 
        array (
        ),
        'as' => 'generated::NvZiYzQgILCd8kft',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7G2KmdJBvYrT58We' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kabid/laporan_gabungan_kabid',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:5',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_gabungan',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_gabungan',
        'namespace' => NULL,
        'prefix' => '/kabid',
        'where' => 
        array (
        ),
        'as' => 'generated::7G2KmdJBvYrT58We',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Qu4dyuaYxmZTun8x' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kabid/laporan_gabungan_generate_kabid',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:5',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_gabungan_excel',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_gabungan_excel',
        'namespace' => NULL,
        'prefix' => '/kabid',
        'where' => 
        array (
        ),
        'as' => 'generated::Qu4dyuaYxmZTun8x',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::59UrAz19A2BXEtld' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kabid/laporan_triwulan_generate_kabid',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:5',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_triwulan_excel',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_triwulan_excel',
        'namespace' => NULL,
        'prefix' => '/kabid',
        'where' => 
        array (
        ),
        'as' => 'generated::59UrAz19A2BXEtld',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oH64s3TpaDw860sl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kabid/laporan_gabungan_rpka_kabid',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:5',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_gabungan_rpka',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_gabungan_rpka',
        'namespace' => NULL,
        'prefix' => '/kabid',
        'where' => 
        array (
        ),
        'as' => 'generated::oH64s3TpaDw860sl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GCNQEqmNI0CFd6fR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kabid/laporan_gabungan_generate_rpka_kabid',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:5',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_gabungan_rpka_excel',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_gabungan_rpka_excel',
        'namespace' => NULL,
        'prefix' => '/kabid',
        'where' => 
        array (
        ),
        'as' => 'generated::GCNQEqmNI0CFd6fR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YgUNhHZb4mny6Gfg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kabid/laporan_triwulan_generate_rpka_kabid',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'role:5',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@report_triwulan_rpka_excel',
        'controller' => 'App\\Http\\Controllers\\ReportController@report_triwulan_rpka_excel',
        'namespace' => NULL,
        'prefix' => '/kabid',
        'where' => 
        array (
        ),
        'as' => 'generated::YgUNhHZb4mny6Gfg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
