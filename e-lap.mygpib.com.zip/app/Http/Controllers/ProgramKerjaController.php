<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Commission;
use App\Models\Department;
use App\Models\ProgramKerja;
use App\Models\ProgramKerjaType;
use App\Models\YearCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProgramKerjaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //
        $auth = Auth::user();
        $department = Department::where('user_id', $auth->id)->first();
        $program_kerja = ProgramKerja::with('year')->orderBy('id', 'desc')->get();
        $year = YearCategory::orderBy('year_name', 'asc')->get();

        $data = [];
        $data['list'] = $program_kerja;
        $data['year'] = $year;
        $data['curr_year'] = $request->year;
        $data['department'] = $department;

        return view('user.program_kerja.index', ['data' => $data]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $auth = Auth::user();
        $department = Department::where('user_id', $auth->id)->first();

        $year = YearCategory::orderBy('year_name', 'asc')->get();
        $list_department = Department::orderBy('department_name', 'asc')->get();
        $commission = Commission::orderBy('name', 'asc')->get();
        $type = ProgramKerjaType::orderBy('name', 'asc')->get();
        $category = Category::orderBy('category_name', 'asc')->get();

        $data = [];
        $data['year'] = $year;
        $data['department'] = $department;
        $data['list_department'] = $list_department;
        $data['commission'] = $commission;
        $data['category'] = $category;
        $data['type'] = $type;

        return view('user.program_kerja.create', ['data' => $data]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
