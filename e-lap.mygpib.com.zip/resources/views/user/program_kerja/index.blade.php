@extends('user/index')

@section('content')
<main>
    <p class="text-center text-secondary font-weight-bold h2 p-3">
        List Program Kerja
    </p>

    <div class="row px-4 justify-content-between">
        <select class="form-select bg-realblue text-white p-2 font-weight-bold rounded" onchange="changeYear(this)">
            @foreach ($data['year'] as $year)
            <option value="{{ $year->year_name }}" @if ($year->year_name == $data['curr_year']) selected @endif>
                {{ $year->year_name }}</option>
            @endforeach
        </select>
        <a class="btn btn-realblue" href="{{url('department/program_kerja/create')}}">Tambah Program Kerja</a>
    </div>

    <div class="container my-2" style="min-height: 50vh">
        <div class="row mt-3">
            <div class="col-md-12">
                <table id="tableData" class="table table-striped" style="width:100%">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Nama Program</th>
                            <th>Tahun</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        @php $no=1; @endphp
                        @foreach ($data['list'] as $item)
                        <tr>
                            <td>{{ $no }}.</td>
                            <td>{{ $item->name }}</td>
                            <td>{{ $year->name }}</td>
                            <td>
                                <a class="btn btn-realblue"
                                    href="{{url('department/program_kerja/'.$item->id.'/edit')}}">Detail</a>
                                <form action="{{ url('department/program_kerja', $datas->id) }}" method="POST"
                                    enctype=multipart/form-data>
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger"
                                        onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Delete</button>
                                </form>
                            </td>
                        </tr>
                        @php $no++; @endphp
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

@endsection