@php $year = date('Y') . ' - ' . date('Y') + 1; @endphp

<div class="bg-white rounded d-none d-md-block">
    <div class="p-3 h6 font-weight-bold">
        <div class="">
            <i class="fa fa-book" style="font-size:20px;"></i>
            <a class="text-dark ml-3" href="{{ url('department/program_kerja?year=' . $year) }}">Program
                Kerja</a>
        </div>
    </div>
</div>

<div class="bg-white rounded d-none d-md-block">
    <div class="p-3 h5 font-weight-bold">
        <div class="">
            <i class="fa fa-book" style="font-size:20px;"></i>
            <a class="text-dark ml-3" href="{{ url('department/dashboard?year=' . $year) }}">Laporan</a>
        </div>
    </div>
</div>